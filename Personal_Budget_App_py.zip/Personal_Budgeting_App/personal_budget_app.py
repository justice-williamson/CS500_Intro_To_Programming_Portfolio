# personal_budget_app.py
# CS-500 Personal Budgeting Application
# Scenario: Personal Budgeting App


import json
from datetime import datetime
from pathlib import Path

# OPTIONAL: for visualization requirement
try:
    import matplotlib.pyplot as plt
    HAS_MPL = True
except Exception:
    HAS_MPL = False


DATA_FILE = Path("budget_data.json")


# ==============================
# Models (OOP)
# ==============================
class ValidationError(ValueError):
    """Custom error for bad user input."""
    pass


class Transaction:
    """Represents a single income or expense entry."""
    def __init__(self, amount: float, category: str, description: str, date_str: str, is_income: bool):
        self.amount = float(amount)
        self.category = category
        self.description = description
        # store as ISO date
        try:
            self.date = datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
            # if bad date, use today but do not crash
            self.date = datetime.today()
        self.is_income = is_income

    def to_dict(self):
        return {
            "amount": self.amount,
            "category": self.category,
            "description": self.description,
            "date": self.date.strftime("%Y-%m-%d"),
            "is_income": self.is_income,
        }

    @staticmethod
    def from_dict(d):
        return Transaction(
            amount=d["amount"],
            category=d["category"],
            description=d.get("description", ""),
            date_str=d.get("date", datetime.today().strftime("%Y-%m-%d")),
            is_income=d.get("is_income", False),
        )


class BudgetCategory:
    """Represents a spending category and optional monthly limit."""
    def __init__(self, name: str, monthly_limit: float = 0.0):
        self.name = name
        self.monthly_limit = float(monthly_limit)

    def to_dict(self):
        return {
            "name": self.name,
            "monthly_limit": self.monthly_limit,
        }

    @staticmethod
    def from_dict(d):
        return BudgetCategory(d["name"], d.get("monthly_limit", 0.0))


class UserBudget:
    """Main budget aggregate: income, expenses, savings goal, categories."""
    def __init__(self, monthly_income: float = 0.0, savings_goal: float = 0.0):
        self.monthly_income = float(monthly_income)
        self.savings_goal = float(savings_goal)
        self.categories = {}  # name -> BudgetCategory
        self.transactions = []  # list[Transaction]

    # ---- core actions ----
    def set_monthly_income(self, amount: float):
        self.monthly_income = float(amount)

    def set_savings_goal(self, amount: float):
        self.savings_goal = float(amount)

    def add_or_update_category(self, name: str, monthly_limit: float = 0.0):
        name = name.strip().title()
        self.categories[name] = BudgetCategory(name, monthly_limit)

    def add_income(self, amount: float, description: str, date_str: str):
        tx = Transaction(amount, "Income", description, date_str, is_income=True)
        self.transactions.append(tx)

    def add_expense(self, amount: float, category: str, description: str, date_str: str):
        cat_name = category.strip().title()
        if cat_name not in self.categories:
            # auto-create category if not present
            self.add_or_update_category(cat_name, 0.0)
        tx = Transaction(amount, cat_name, description, date_str, is_income=False)
        self.transactions.append(tx)

    # ---- analytics ----
    def monthly_summary(self, year: int, month: int):
        incomes = []
        expenses = []
        for tx in self.transactions:
            if tx.date.year == year and tx.date.month == month:
                if tx.is_income:
                    incomes.append(tx)
                else:
                    expenses.append(tx)

        total_income = round(sum(t.amount for t in incomes), 2)
        total_expense = round(sum(t.amount for t in expenses), 2)
        net = round(total_income - total_expense, 2)

        by_cat = {}
        for tx in expenses:
            by_cat[tx.category] = round(by_cat.get(tx.category, 0.0) + tx.amount, 2)

        # savings progress = how much of net moves toward savings_goal
        if self.savings_goal > 0:
            progress = min(1.0, max(0.0, net / self.savings_goal))
        else:
            progress = 0.0

        return {
            "total_income": total_income,
            "total_expense": total_expense,
            "net": net,
            "by_category": by_cat,
            "progress": progress,
            "incomes": incomes,
            "expenses": expenses,
        }

    # ---- persistence ----
    def to_dict(self):
        return {
            "monthly_income": self.monthly_income,
            "savings_goal": self.savings_goal,
            "categories": {name: cat.to_dict() for name, cat in self.categories.items()},
            "transactions": [t.to_dict() for t in self.transactions],
        }

    @staticmethod
    def from_dict(d):
        b = UserBudget(d.get("monthly_income", 0.0), d.get("savings_goal", 0.0))
        for name, cat_d in d.get("categories", {}).items():
            b.categories[name] = BudgetCategory.from_dict(cat_d)
        for tx_d in d.get("transactions", []):
            b.transactions.append(Transaction.from_dict(tx_d))
        return b


# ==============================
# Validation helpers
# ==============================
def read_positive_float(prompt_msg: str) -> float:
    raw = input(prompt_msg).strip()
    if raw == "":
        raise ValidationError("This field is required.")
    try:
        value = float(raw)
    except ValueError:
        raise ValidationError("Please enter a number.")
    if value < 0:
        raise ValidationError("Value cannot be negative.")
    return value


def read_nonempty(prompt_msg: str) -> str:
    raw = input(prompt_msg).strip()
    if raw == "":
        raise ValidationError("This field cannot be empty.")
    return raw


def read_date(prompt_msg: str) -> str:
    raw = input(prompt_msg + " (YYYY-MM-DD): ").strip()
    if raw == "":
        # allow blank, use today
        return datetime.today().strftime("%Y-%m-%d")
    try:
        datetime.strptime(raw, "%Y-%m-%d")
    except ValueError:
        raise ValidationError("Date must be in format YYYY-MM-DD.")
    return raw


# ==============================
# File I/O
# ==============================
def load_budget() -> UserBudget:
    if not DATA_FILE.exists():
        return UserBudget()
    with DATA_FILE.open("r", encoding="utf-8") as f:
        data = json.load(f)
    return UserBudget.from_dict(data)


def save_budget(budget: UserBudget):
    tmp = DATA_FILE.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(budget.to_dict(), f, indent=2)
    tmp.replace(DATA_FILE)


# ==============================
# Visualization
# ==============================
def show_category_chart(summary: dict):
    if not HAS_MPL:
        print("matplotlib not installed. Skipping chart.")
        return
    by_cat = summary["by_category"]
    if not by_cat:
        print("No expenses to visualize.")
        return
    labels = list(by_cat.keys())
    values = list(by_cat.values())
    plt.figure()
    plt.title("Spending by Category")
    plt.bar(labels, values)
    plt.xticks(rotation=30, ha="right")
    plt.tight_layout()
    plt.show()


# ==============================
# CLI
# ==============================
def print_menu():
    print("\n=== Personal Budgeting App ===")
    print("1. Set monthly income")
    print("2. Set savings goal")
    print("3. Add / update category")
    print("4. Add income")
    print("5. Add expense")
    print("6. View monthly summary")
    print("7. Show spending chart (by category)")
    print("0. Save and Exit")


def main():
    budget = load_budget()
    print(f"Loaded budget from: {DATA_FILE}")

    while True:
        print_menu()
        choice = input("Choose an option: ").strip()

        try:
            if choice == "1":
                amt = read_positive_float("Enter monthly income: ")
                budget.set_monthly_income(amt)
                print("Monthly income updated.")

            elif choice == "2":
                goal = read_positive_float("Enter monthly savings goal: ")
                budget.set_savings_goal(goal)
                print("Savings goal updated.")

            elif choice == "3":
                name = read_nonempty("Enter category name: ").title()
                limit = read_positive_float("Enter monthly limit (0 for none): ")
                budget.add_or_update_category(name, limit)
                print(f"Category '{name}' updated.")

            elif choice == "4":
                amt = read_positive_float("Enter income amount: ")
                desc = input("Enter income description (optional): ").strip()
                date_str = read_date("Enter income date")
                budget.add_income(amt, desc, date_str)
                print("Income recorded.")

            elif choice == "5":
                amt = read_positive_float("Enter expense amount: ")
                cat = read_nonempty("Enter expense category: ")
                desc = input("Enter expense description (optional): ").strip()
                date_str = read_date("Enter expense date")
                budget.add_expense(amt, cat, desc, date_str)
                print("Expense recorded.")

            elif choice == "6":
                # ask month/year
                now = datetime.today()
                year_raw = input(f"Enter year [{now.year}]: ").strip() or str(now.year)
                month_raw = input(f"Enter month (1-12) [{now.month}]: ").strip() or str(now.month)
                year = int(year_raw)
                month = int(month_raw)

                summary = budget.monthly_summary(year, month)
                print(f"\n--- Summary for {year}-{month:02d} ---")
                print(f"Total income:  ${summary['total_income']:.2f}")
                print(f"Total expense: ${summary['total_expense']:.2f}")
                print(f"Net:           ${summary['net']:.2f}")
                print("\nSpending by category:")
                for cat, amt in summary["by_category"].items():
                    print(f"  {cat:<15} ${amt:>8.2f}")
                print(f"\nSavings goal:  ${budget.savings_goal:.2f}")
                print(f"Progress:      {int(summary['progress'] * 100)}%")

            elif choice == "7":
                now = datetime.today()
                summary = budget.monthly_summary(now.year, now.month)
                show_category_chart(summary)

            elif choice == "0":
                save_budget(budget)
                print("Budget saved. Goodbye.")
                break

            else:
                print("Please choose a valid option.")

            # autosave after each operation
            save_budget(budget)

        except ValidationError as ve:
            print(f"Input error: {ve}")
        except Exception as e:
            # secure-ish handling (don’t crash)
            print(f"Unexpected error: {e}")

if __name__ == "__main__":
    main()
