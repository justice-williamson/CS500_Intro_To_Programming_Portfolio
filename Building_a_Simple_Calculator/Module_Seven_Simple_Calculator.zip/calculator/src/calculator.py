def add(a: float, b: float) -> float:
    return a + b

def subtract(a: float, b: float) -> float:
    return a - b

def multiply(a: float, b: float) -> float:
    return a * b

def divide(a: float, b: float) -> float:
    if b == 0:
        raise ZeroDivisionError("Cannot divide by zero.")
    return a / b

def read_float(prompt: str) -> float:
    while True:
        raw = input(prompt)
        try:
            return float(raw)
        except ValueError:
            print("Invalid number. Please try again.")

def main():
    MENU = (
        "\nSimple Calculator\n"
        "1) Add\n"
        "2) Subtract\n"
        "3) Multiply\n"
        "4) Divide\n"
        "5) Exit\n"
        "Select an option (1-5): "
    )

    while True:
        choice_raw = input(MENU).strip()
        if choice_raw == "5":
            print("Goodbye!")
            break

        if choice_raw not in {"1", "2", "3", "4"}:
            print("Invalid selection. Please choose 1-5.")
            continue

        a = read_float("Enter first number: ")
        b = read_float("Enter second number: ")

        try:
            if choice_raw == "1":
                result = add(a, b)
            elif choice_raw == "2":
                result = subtract(a, b)
            elif choice_raw == "3":
                result = multiply(a, b)
            else:
                result = divide(a, b)
            print(f"Result: {result}")
        except ZeroDivisionError as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    main()
