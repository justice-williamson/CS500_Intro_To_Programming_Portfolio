# Module Seven Calculator

## How to Run
python3 src/calculator.py

## How to Run Tests
PYTHONPATH=. python3 -m unittest discover -s tests -p "test_*.py"

## Project Structure
.
├── src/
│   └── calculator.py
├── tests/
│   └── test_calculator.py
├── docs/
│   └── Process Summary.docx (or .pdf)
├── flowchart/
│   └── calculator_flowchart.vsdx
└── screenshots/
    ├── unit_test_results.png
    └── division_by_zero.png

## Notes
- Requires Python 3.x
- Division by zero prints: "Error: Cannot divide by zero."
